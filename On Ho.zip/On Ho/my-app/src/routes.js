import React from 'react';
import Login from './components/LoginAdmin.js';
import AllProduct from './components/Allproduct.js';
import ProductList from './components/ProductList.js';
import ProductDetail from './components/ChitietSp.js';
import Add from './components/Add.js';
// import Contact from './components/Contact.js';
// import ContactList from './components/ContactList.js';
// import Confirm from './components/Confirm.js';
// import Introduce from './components/Introduce.js';
// import SanPhamMoi from './components/SanPhamMoi.js';
// import SanPhamHot from './components/SanPhamHot.js';
// import SanPhamKhuyenMai from './components/SanPhamKhuyenMai.js';
import DetailAdmin from './components/DetailAdmin.js';
// import NotFound from './components/NotFound.js';
// import ContactDetail from './components/ContactDetail.js';

const routes = [
	{
		path : '/',
		exact : true,
		main : ()=> <AllProduct />
	},
	{
		path : '/login',
		exact : true,
		main : ({history})=> <Login history={history} />
    },
    {
		path : '/product-list',
		exact : true,
		main : ()=> <ProductList />
	},
	
	{
		path : '/products/:id/productdetail',
		exact : true,
		main : ({match})=> <ProductDetail  match ={match}/>
	},
	{
		path : '/add',
		exact : true,
		main : ({history})=> <Add history={history} />
    },
    {
		path : '/products/:id/edit',
		exact : true,
		main : ({match , history})=> <Add  match ={match} history={history}/>
    },
    {
		path : '/products/:id/prodetailadmin',
		exact : true,
		main : ({match})=> <DetailAdmin match ={match}/>
	},
];


export default routes;