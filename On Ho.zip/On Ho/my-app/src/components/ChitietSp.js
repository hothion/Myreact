import React, {Component} from 'react';
import axios from 'axios';
import Slide from './layout_user/Slide.js';
import Header from './layout_user/Header.js';
import Footer from './layout_user/Footer.js';
class ProductDetail extends Component {
	constructor(props){
        super(props)
        this.state = {
           products : []
        }
    }    
    componentDidMount(){
      var {match} = this.props;
      if (match) {
      	var id = match.params.id;
      	axios({
        method: 'GET',
        url :'http://localhost:3000/products/${id}',
        data : null
     	 }).then(res =>{
     	 	var data =res.data;
        	this.setState({
         	 products :res.data
        	});
      		}).catch( err =>{
        	console.log(err);
      		});
    	}
      }
 render() {
 	var {products} = this.state;
  	return (
      <React.Fragment>
        <Header />
       <div className="mt-2">
          <Slide />
        </div>
       <div className="container mb-5 mt-5">
       <h4 className="txtdeepshadow text-center text-danger mb-5">Chi tiết Sản phẩm</h4>
        <div className="row">       
        <div className="col-sm-4">
          <img src={this.state.products.image} height="300" width="300" alt="" />
        </div>
        <div className="col-sm-3">
          <div className="single-item-body">
            <h4 className="single-item-title">{this.state.products.name}</h4>
            <p className="single-item-price">
              <span>${this.state.products.price}</span>
            </p>
          </div>
          {/* <div className="clearfix" /> */}
          <div className="single-item-options">
            <h4 className="single-item-title">Xuất sứ: {this.state.products.origin}</h4>
            <div className="clearfix" />
          </div>
        </div>
 </div>
      <div className="woocommerce-tabs">

            <div className="panel" id="tab-description" style={{ display: "block" }}>
              <p>
                {this.state.products.description}
              </p>
            </div>
           
          </div>
       </div>         
        <Footer />    
        </React.Fragment>
   		);
	}
}

export default ProductDetail;