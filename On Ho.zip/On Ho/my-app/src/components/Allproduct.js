import React,{Component}from 'react';
import Slide from './layout_user/Slide';
import Header from './layout_user/Header';
import Footer from './layout_user/Footer';
import axios from 'axios';

import { BrowserRouter as Router, Route, NavLink } from 'react-router-dom';


class Allproduct extends Component{
  constructor(props){
    super(props)
    this.state = {
       products : [],
       sort : true,       
    }
}    
componentDidMount(){
  axios({
    method: 'GET',
    url :'http://localhost:3000/products',
    data : null
  }).then(res =>{
    this.setState({
      products :res.data
    });
  }).catch( err =>{
  });
}
componentWillUpdate(){
  if (this.state.sort === true) {
      axios({
        method: 'GET',
        url :'http://localhost:3000/products?_sort=price&_order=desc&_limit=6',
        data : null
      }).then(res =>{
        this.setState({
          products :res.data
        });
      }).catch( err =>{
      });
  }else{
      axios({
      method: 'GET',
      url :'http://localhost:3000/products?_sort=price&_order=desc&_limit=6',
      data : null
      }).then(res =>{
        this.setState({
          products :res.data
        });
      }).catch( err =>{
      });
  }
  
}
onChange = (event) =>{
  var target = event.target;
  var name = target.name;
  var value = target.value;
  this.setState({
    [name] : value
  });
}
  render(){
    var { products,keyword } = this.state;
   return(
    <React.Fragment>
    <Header/>
    <br/>
    <div className="mt-2">
          <Slide />
        </div>
        
        <div className="container mb-5 mt-5">
        <marquee width="80%" scrollamount="10"color="red"><h4 className="txtdeepshadow" >Các loại giay tại cửa hàng</h4></marquee>
          <div className="row">
           {this.state.products.map((product,index) => {
                         return < Item key={index} product={product} />
                })}
       </div>    
       </div>    
   
    <Footer/>

   
   </React.Fragment>
    );
  }
}


class Item extends Component{
  render(){
    return(
    
  
      <div className="col-md-4 mt-2">
        <div className="card">
        <div className="ribbon-wrapper"><div className="ribbon sale">{this.showType(this.props.product.name_category)}</div></div>
          <div className="card-body">
          <NavLink to={`/products/${this.props.product.id}/productdetail`}>
            <div className="card-img-actions"> <img src={this.props.product.image} className="card-img img-fluid" width={96} height={350} alt="" /> </div>
            </NavLink>
          </div>
          <div className="card-body bg-light text-center">
            <div className="mb-2">
           
              <h6 className="font-weight-semibold mb-2">{this.props.product.name} </h6>
              
            <h3 className="mb-0 font-weight-semibold">$ {this.props.product.price}</h3>
            <div> <i className="fa fa-star star" /> <i className="fa fa-star star" /> <i className="fa fa-star star" /> <i className="fa fa-star star" /> </div>
             <button type="button" className="btn bg-cart"><i className="fa fa-cart-plus mr-2" /> Add to cart</button>
          </div>
        </div>
      </div>
    </div>
    
  
    )
  }

  showType(name_category){
    var kq = '';
    if (name_category === 'sản phẩm mới') {
        kq = "New"
    }else if (name_category === 'sản phẩm hot') {
        kq = "Hot"
    }else if (name_category === 'sản phẩm khuyến mãi'){
        kq = "Sale"
    }
    return kq;
  }
}
export default Allproduct;
