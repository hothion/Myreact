import React, {Component} from 'react';
import { NavLink } from 'react-router-dom';
 class Header extends Component{
    render(){
        return(
<nav className="navbar navbar-expand-md navbar-dark bg-dark">
<div className="container">
  {/* <a className="navbar-brand" href="index.html">Simple Ecommerce</a> */}
  <img src="./images/logo.png" width="100px" left="0px" alt="" />
  <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
    <span className="navbar-toggler-icon" />
  </button>
  <div className="collapse navbar-collapse justify-content-end" id="navbarsExampleDefault">
    <ul className="navbar-nav m-auto">
      <li className="nav-item">
        <a className="nav-link" href="index.html">Home</a>
      </li>
      <li className="nav-item">
        <a className="nav-link" href="product.html">Contact</a>
      </li>
      <li className="nav-item">
        <a className="nav-link" href="product.html">About</a>
      </li>
      <li className="nav-item">
        <a className="nav-link" href="cart.html">Cart</a>
      </li>
      <li className="nav-item">
        <NavLink className="nav-link" to="/login">Login</NavLink>
      </li>
    </ul>
    <form className="form-inline my-2 my-lg-0">
      <div className="input-group input-group-sm">
        <input type="text" className="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" placeholder="Search..." />
        <div className="input-group-append">
          <button type="button" className="btn btn-secondary btn-number">
            <i className="fa fa-search" />
          </button>
        </div>
      </div>
      <a className="btn btn-success btn-sm ml-3" href="cart.html">
        <i className="fa fa-shopping-cart" /> Cart
        <span className="badge badge-light">3</span>
      </a>
    </form>
  </div>
</div>
</nav>
        )
    }
}
export default Header;